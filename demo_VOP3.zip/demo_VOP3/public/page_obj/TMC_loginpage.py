#!/usr/bin/env python
# _*_ coding:utf-8 _*_
__author__ = 'YinJia'

import os,sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from config import setting
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from public.page_obj.base import Page
from time import sleep
from public.models.GetYaml import getyaml
from public.models.log import Log
import time

testData = getyaml(setting.TEST_Element_YAML + '/' + 'tmc_login.yaml')
log = Log()

class sys_login(Page):
    '''TMC用户登陆页面'''
    url = '/'
    # 定位器，通过元素属性定位元素对象
    # 输入用户名
    user = (By.ID, testData.get_elementinfo(0))
    # 输入密码
    pwd = (By.ID, testData.get_elementinfo(1))
    # 点击登陆按钮
    loginbutton = (By.XPATH, testData.get_elementinfo(2))

    def login_user(self,name):
        """
        登录账号
        :param name:
        :return:
        """
        self.driver.find_element(*self.user).send_keys(name)

    def login_passwd(self,passwd):
        """
        登录密码
        :param passwd:
        :return:
        """
        self.driver.find_element(*self.pwd).send_keys(passwd)

    def click_loginbutton(self):
        """
        取消单选自动登录
        :return:
        """
        self.driver.find_element(*self.loginbutton).click()

    def tmc_user_login(self,name,password):
        """
        登录入口
        :param username: 用户名
        :param password: 密码
        :return:
        """
        self.open()
        time.sleep(2)
        self.login_user(name)
        self.login_passwd(password)
        sleep(1)
        self.click_loginbutton()
        sleep(1)


