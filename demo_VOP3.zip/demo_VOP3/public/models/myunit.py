#!/usr/bin/env python
# _*_ coding:utf-8 _*_
__author__ = 'YinJia'

from .driver import browser
import unittest
import os
from selenium import webdriver


class MyTest(unittest.TestCase):
    """
    自定义MyTest类
    """
    @classmethod
    def setUp(self):
        self.driver = browser()
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()

    @classmethod
    def tearDown(self):
        self.driver.quit()